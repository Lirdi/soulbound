#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:matrix.glsl>
#include <minecraft:globals.glsl>

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;

layout(location = 0) in vec4 texProj0;
layout(location = 1) in float sphericalVertexDistance;
layout(location = 2) in float cylindricalVertexDistance;

const vec3[] COLORS = vec3[](
    vec3(0.070000, 0.068000, 0.050000),
    vec3(0.074667, 0.071333, 0.050667),
    vec3(0.079333, 0.074667, 0.051333),
    vec3(0.084000, 0.078000, 0.052000),
    vec3(0.088667, 0.081333, 0.052667),
    vec3(0.093333, 0.084667, 0.053333),
    vec3(0.098000, 0.088000, 0.054000),
    vec3(0.102667, 0.091333, 0.054667),
    vec3(0.107333, 0.094667, 0.055333),
    vec3(0.112000, 0.098000, 0.056000),
    vec3(0.116667, 0.101333, 0.056667),
    vec3(0.121333, 0.104667, 0.057333),
    vec3(0.126000, 0.108000, 0.058000),
    vec3(0.130667, 0.111333, 0.058667),
    vec3(0.135333, 0.114667, 0.059333),
    vec3(0.140000, 0.118000, 0.060000)
);

const mat4 SCALE_TRANSLATE = mat4(
    0.5, 0.0, 0.0, 0.25,
    0.0, 0.5, 0.0, 0.25,
    0.0, 0.0, 1.0, 0.0,
    0.0, 0.0, 0.0, 1.0
);

mat4 end_portal_layer(float layer) {
    mat4 translate = mat4(
        1.0, 0.0, 0.0, 17.0 / layer,
        0.0, 1.0, 0.0, (2.0 + layer / 1.5) * (GameTime * 1.5),
        0.0, 0.0, 1.0, 0.0,
        0.0, 0.0, 0.0, 1.0
    );

    mat2 rotate = mat2_rotate_z(radians((layer * layer * 4321.0 + layer * 9.0) * 2.0));

    mat2 scale = mat2((4.5 - layer / 4.0) * 2.0);

    return mat4(scale * rotate) * translate * SCALE_TRANSLATE;
}

// Heaven: the portal is a window into the sky above the clouds. Clear blue, soft white cloud drifting through it,
// a few gold glints of light, and a slow breathing glow.
float hh(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(hh(i), hh(i + vec2(1.0, 0.0)), u.x), mix(hh(i + vec2(0.0, 1.0)), hh(i + vec2(1.0, 1.0)), u.x), u.y);
}
float fbm(vec2 p) {
    float v = 0.0, a = 0.5;
    for (int i = 0; i < 5; i++) { v += a * vnoise(p); p = p * 2.03 + vec2(17.3, 9.1); a *= 0.5; }
    return v;
}
vec3 heaven(vec4 proj) {
    vec2 uv = proj.xy / proj.w;
    float t = fract(GameTime * 8.0) * 600.0;   // drift (wraps slowly; noise is continuous enough not to notice)
    float c1 = fbm(uv * 3.0 + vec2(t * 0.020, t * 0.006));
    float c2 = fbm(uv * 6.5 - vec2(t * 0.034, -t * 0.011) + 4.0);
    float cloud = smoothstep(0.42, 0.78, c1 * 0.65 + c2 * 0.45);
    float breathe = 0.92 + 0.08 * sin(GameTime * 1200.0);
    vec3 deep = vec3(0.22, 0.47, 0.90);
    vec3 pale = vec3(0.58, 0.80, 1.00);
    vec3 sky = mix(deep, pale, smoothstep(0.25, 0.75, c1)) * breathe;
    vec3 col = mix(sky, vec3(0.97, 0.98, 1.0), cloud * 0.85);
    // sunlit cloud edges
    col += vec3(1.0, 0.86, 0.55) * smoothstep(0.55, 0.62, c1 * 0.65 + c2 * 0.45) * (1.0 - cloud) * 0.35;
    return col;
}

layout(location = 0) out vec4 fragColor;

void main() {
    vec3 color = heaven(texProj0);
    for (int i = 0; i < PORTAL_LAYERS; i++) {
        color += textureProj(Sampler1, texProj0 * end_portal_layer(float(i + 1))).rgb * COLORS[i];
    }
    fragColor = apply_fog(vec4(min(color, vec3(1.0)), 1.0), sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
