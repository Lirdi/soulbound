#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:matrix.glsl>
#include <minecraft:globals.glsl>

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;

layout(location = 0) in vec4 texProj0;
layout(location = 1) in float sphericalVertexDistance;
layout(location = 2) in float cylindricalVertexDistance;

// Heaven: the portal surface is liquid gold light instead of the void
const vec3[] COLORS = vec3[](
    vec3(0.160000, 0.140000, 0.080000),
    vec3(0.180000, 0.160000, 0.088876),
    vec3(0.200000, 0.180000, 0.101855),
    vec3(0.220000, 0.200000, 0.117022),
    vec3(0.240000, 0.220000, 0.133812),
    vec3(0.260000, 0.240000, 0.151922),
    vec3(0.280000, 0.260000, 0.171159),
    vec3(0.300000, 0.280000, 0.191386),
    vec3(0.320000, 0.300000, 0.212501),
    vec3(0.340000, 0.320000, 0.234425),
    vec3(0.360000, 0.340000, 0.257093),
    vec3(0.380000, 0.360000, 0.280453),
    vec3(0.400000, 0.380000, 0.304460),
    vec3(0.420000, 0.400000, 0.329074),
    vec3(0.440000, 0.420000, 0.354264),
    vec3(0.460000, 0.440000, 0.380000)
);

const mat4 SCALE_TRANSLATE = mat4(
    0.5, 0.0, 0.0, 0.25,
    0.0, 0.5, 0.0, 0.25,
    0.0, 0.0, 1.0, 0.0,
    0.0, 0.0, 0.0, 1.0
);

mat4 end_portal_layer(float layer) {
    mat4 translate = mat4(
        1.0, 0.0, 0.0, 17.0 / layer,
        0.0, 1.0, 0.0, (2.0 + layer / 1.5) * (GameTime * 1.5),
        0.0, 0.0, 1.0, 0.0,
        0.0, 0.0, 0.0, 1.0
    );

    mat2 rotate = mat2_rotate_z(radians((layer * layer * 4321.0 + layer * 9.0) * 2.0));

    mat2 scale = mat2((4.5 - layer / 4.0) * 2.0);

    return mat4(scale * rotate) * translate * SCALE_TRANSLATE;
}

layout(location = 0) out vec4 fragColor;

void main() {
    // a warm glow under everything, breathing slowly, so the gold never goes dark between the drifting motes
    float breathe = 0.85 + 0.15 * sin(GameTime * 1200.0);
    vec3 color = vec3(0.86, 0.66, 0.26) * breathe + textureProj(Sampler0, texProj0).rgb * vec3(0.12, 0.10, 0.05);
    for (int i = 0; i < PORTAL_LAYERS; i++) {
        color += textureProj(Sampler1, texProj0 * end_portal_layer(float(i + 1))).rgb * COLORS[i];
    }
    fragColor = apply_fog(vec4(color, 1.0), sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
