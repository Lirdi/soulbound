#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 UV0;
layout(location = 2) in vec4 Color;
layout(location = 3) in ivec2 UV2;

uniform sampler2D Sampler2;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
layout(location = 2) out vec2 texCoord0;
layout(location = 3) out vec4 vertexColor;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    texCoord0 = UV0;
    // Soulbound: the dragon here is God, so his breath is gold, not purple. Dragon breath is the only particle
    // tinted pure violet with no green at all (0xB700D2..0xDF00F9); turn exactly that into holy gold.
    vec4 c = Color;
    if (c.g < 0.02 && c.r > 0.66 && c.r < 0.92 && c.b > 0.78) {
        float k = clamp((c.r - 0.70) / 0.18, 0.0, 1.0);
        c.rgb = mix(vec3(1.0, 0.78, 0.30), vec3(1.0, 0.95, 0.70), k);
    }
    vertexColor = c * sample_lightmap(Sampler2, UV2);
}
