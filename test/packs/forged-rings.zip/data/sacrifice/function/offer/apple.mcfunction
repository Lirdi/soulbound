execute store result score #n sacrifice.offer run data get entity @s Item.count
scoreboard players set #k sacrifice.offer 100
scoreboard players operation #n sacrifice.offer *= #k sacrifice.offer
function sacrifice:offer/feed
kill @s
particle minecraft:flame ~ ~0.5 ~ 0.4 0.6 0.4 0.03 40
execute if score #msg sacrifice.offer matches ..0 run playsound minecraft:entity.ravager.roar hostile @a ~ ~ ~ 2 0.5
particle minecraft:lava ~ ~1 ~ 0.6 0.6 0.6 0 30
execute if score #msg sacrifice.offer matches ..0 as @p[distance=..24] run title @s title {text:"MOLOCH ACCEPTS",color:"dark_red",bold:true}
execute store result score #r sacrifice.offer run random value 0..3
execute if score #r sacrifice.offer matches 0 as @p[distance=..24] run effect give @s minecraft:strength 300 1
execute if score #r sacrifice.offer matches 1 as @p[distance=..24] run effect give @s minecraft:resistance 300 0
execute if score #r sacrifice.offer matches 2 as @p[distance=..24] run effect give @s minecraft:absorption 120 3
execute if score #r sacrifice.offer matches 3 as @p[distance=..24] run effect give @s minecraft:hero_of_the_village 600 0
scoreboard players set #msg sacrifice.offer 30
