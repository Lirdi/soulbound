# however much goes in at once, the realm is blessed once
execute unless score #total sacrifice.offer matches 125.. run return 0
scoreboard players set #c25 sacrifice.offer 125
scoreboard players operation #total sacrifice.offer %= #c25 sacrifice.offer
execute in sacrifice:sacrifice as @a[x=-4096,y=-64,z=-4096,dx=8192,dy=512,dz=8192] run effect give @s minecraft:strength 120 0
tellraw @a {text:"Moloch is fed. The fires burn brighter.",color:"dark_red",bold:true}
