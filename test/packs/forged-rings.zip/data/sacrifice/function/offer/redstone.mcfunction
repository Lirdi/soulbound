# red dust: 2 points (0.2% Hunger) each, counted for the whole stack at once
execute store result score #n sacrifice.offer run data get entity @s Item.count
scoreboard players set #k sacrifice.offer 2
scoreboard players operation #n sacrifice.offer *= #k sacrifice.offer
function sacrifice:offer/feed
kill @s
# the show (sound, flames, a blessing, the line) at most once every 1.5 seconds, however many single dusts are thrown
execute if score #msg sacrifice.offer matches 1.. run return 0
particle minecraft:flame ~ ~0.5 ~ 0.4 0.6 0.4 0.03 40
playsound minecraft:block.fire.extinguish block @a ~ ~ ~ 1 0.6
execute store result score #r sacrifice.offer run random value 0..4
execute if score #r sacrifice.offer matches 0 as @p[distance=..24] run effect give @s minecraft:strength 180 0
execute if score #r sacrifice.offer matches 1 as @p[distance=..24] run effect give @s minecraft:haste 180 1
execute if score #r sacrifice.offer matches 2 as @p[distance=..24] run effect give @s minecraft:regeneration 30 0
execute if score #r sacrifice.offer matches 3 as @p[distance=..24] run effect give @s minecraft:fire_resistance 300 0
execute as @p[distance=..24] run tellraw @s {text:"The fire drinks the red dust.",color:"dark_red",italic:true}
scoreboard players set #msg sacrifice.offer 30
