# The World Egg: God's own egg, thrown into his son's fire. Feeds Moloch 30% (300 points at 0.1% each) per egg and the whole server hears of it.
execute store result score #n sacrifice.offer run data get entity @s Item.count
scoreboard players set #k sacrifice.offer 300
scoreboard players operation #n sacrifice.offer *= #k sacrifice.offer
function sacrifice:offer/feed
kill @s
tellraw @a [{"text":"","color":"dark_red"},{"selector":"@p[distance=..24]","color":"gold"},{"text":" fed Moloch the World Egg. ","color":"dark_red","bold":true},{"text":"His father's child, gone into the fire. He grows hungrier.","color":"red","italic":true}]
execute as @a run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.8 0.5
execute as @a run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.6 0.6
particle minecraft:dragon_breath ~ ~1 ~ 0.6 1 0.6 0.05 120
