# test it: stand somewhere open and run /function sacrifice:mob/worshipper_2/spawn
function sacrifice:mob/worshipper_2/group
