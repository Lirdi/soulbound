function sacrifice:mob/worshipper_2/summon
function sacrifice:mob/worshipper_2/summon
function sacrifice:mob/worshipper_2/summon
