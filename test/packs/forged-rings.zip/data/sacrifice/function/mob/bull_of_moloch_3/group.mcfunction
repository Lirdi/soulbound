function sacrifice:mob/bull_of_moloch_3/summon
