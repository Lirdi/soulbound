function sacrifice:mob/blood_priest_1/summon
