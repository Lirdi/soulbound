# test it: stand somewhere open and run /function sacrifice:mob/blood_priest_1/spawn
function sacrifice:mob/blood_priest_1/group
