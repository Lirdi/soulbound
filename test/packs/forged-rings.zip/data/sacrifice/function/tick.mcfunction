execute if score #msg sacrifice.offer matches 1.. run scoreboard players remove #msg sacrifice.offer 1
# Blood Priest
execute as @a at @s if dimension sacrifice:sacrifice store result score @s sacrifice.near if entity @e[tag=sacrifice_blood_priest_1,distance=..72]
execute as @a[scores={sacrifice.near=..1}] at @s rotated ~ 0 if dimension sacrifice:sacrifice if predicate sacrifice:roll_blood_priest_1 positioned ^ ^ ^32 unless predicate sacrifice:in_temple run function sacrifice:mob/blood_priest_1/place
# Worshipper
execute as @a at @s if dimension sacrifice:sacrifice store result score @s sacrifice.near if entity @e[tag=sacrifice_worshipper_2,distance=..72]
execute as @a[scores={sacrifice.near=..2}] at @s rotated ~ 0 if dimension sacrifice:sacrifice if predicate sacrifice:roll_worshipper_2 positioned ^ ^ ^24 unless predicate sacrifice:in_temple run function sacrifice:mob/worshipper_2/place
execute as @a[scores={sacrifice.near=..2}] at @s rotated ~90 0 if dimension sacrifice:sacrifice if predicate sacrifice:roll_worshipper_2 positioned ^ ^ ^24 unless predicate sacrifice:in_temple run function sacrifice:mob/worshipper_2/place
execute as @a[scores={sacrifice.near=..2}] at @s rotated ~180 0 if dimension sacrifice:sacrifice if predicate sacrifice:roll_worshipper_2 positioned ^ ^ ^24 unless predicate sacrifice:in_temple run function sacrifice:mob/worshipper_2/place
execute as @a[scores={sacrifice.near=..2}] at @s rotated ~270 0 if dimension sacrifice:sacrifice if predicate sacrifice:roll_worshipper_2 positioned ^ ^ ^24 unless predicate sacrifice:in_temple run function sacrifice:mob/worshipper_2/place
# Bull of Moloch
execute as @a at @s if dimension sacrifice:sacrifice store result score @s sacrifice.near if entity @e[tag=sacrifice_bull_of_moloch_3,distance=..72]
execute as @a[scores={sacrifice.near=..0}] at @s rotated ~ 0 if dimension sacrifice:sacrifice if predicate sacrifice:roll_bull_of_moloch_3 positioned ^ ^ ^48 unless predicate sacrifice:in_temple run function sacrifice:mob/bull_of_moloch_3/place
# offerings thrown into the summit pit
execute in sacrifice:sacrifice as @e[type=item,x=-1.5,y=125,z=-1.5,dx=3,dy=13,dz=3] at @s run function sacrifice:offer/item
# shown once each time someone reaches the summit (not every tick, so it doesn't drown out other messages)
execute in sacrifice:sacrifice as @a[x=-9,y=132,z=-9,dx=18,dy=8,dz=18,tag=!sacrifice_hint] run title @s actionbar {text:"Feed the fire. Moloch is hungry.",color:"dark_red",italic:true}
execute in sacrifice:sacrifice as @a[x=-9,y=132,z=-9,dx=18,dy=8,dz=18,tag=!sacrifice_hint] run tag @s add sacrifice_hint
execute in sacrifice:sacrifice as @a[tag=sacrifice_hint] unless entity @s[x=-14,y=126,z=-14,dx=28,dy=16,dz=28] run tag @s remove sacrifice_hint
# Bastard Thief (spawned by hand only: /function sacrifice:thief/spawn)
execute as @e[tag=sacrifice_thief] at @s run tp @n[tag=sacrifice_thief_skin,distance=..4] ~ ~ ~ ~ ~
execute as @e[tag=sacrifice_thief_skin] at @s run function sacrifice:thief/skin
execute as @e[tag=sacrifice_thief_fled] at @s run function sacrifice:thief/flee
execute as @e[tag=sacrifice_thief,tag=!sacrifice_thief_fled,tag=!sacrifice_thief_greeted] at @s if entity @a[distance=..6] run function sacrifice:thief/greet
