scoreboard objectives add sacrifice.near dummy
scoreboard objectives add sacrifice.offer dummy
scoreboard objectives add sacrifice.thief dummy
team add sacrifice_thief_skins
team modify sacrifice_thief_skins collisionRule never
schedule function sacrifice:cleanup 100t replace
