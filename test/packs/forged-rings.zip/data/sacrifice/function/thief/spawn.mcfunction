# spawn the Bastard Thief where you stand (he never spawns on his own):
#   /function sacrifice:thief/spawn
# or at a player:  /execute at <player> run function sacrifice:thief/spawn
function sacrifice:thief/summon
