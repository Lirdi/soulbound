# you had nothing worth taking
tag @s remove sacrifice_thief_grabbing
tag @s add sacrifice_thief_angry
effect give @s minecraft:strength 15 2
effect give @s minecraft:speed 15 1
particle minecraft:angry_villager ~ ~2.2 ~ 0.3 0.2 0.3 0 6
playsound minecraft:entity.vindicator.ambient hostile @a ~ ~ ~ 1 0.6
