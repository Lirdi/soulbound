# runs straight away from the nearest player, stepping up single blocks
execute unless entity @a[distance=..48] run return run function sacrifice:thief/escape
execute facing entity @p feet rotated ~180 0 positioned ^ ^ ^0.40 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable unless block ~ ~ ~ minecraft:lava run tp @s ~ ~ ~ facing ^ ^ ^1
execute facing entity @p feet rotated ~180 0 positioned ^ ^ ^0.40 unless block ~ ~ ~ #minecraft:replaceable positioned ~ ~1 ~ if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable unless block ~ ~ ~ minecraft:lava run tp @s ~ ~ ~ facing ^ ^ ^1
particle minecraft:smoke ~ ~0.4 ~ 0.15 0.1 0.15 0 1
