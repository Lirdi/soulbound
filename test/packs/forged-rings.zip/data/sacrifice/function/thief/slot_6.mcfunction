data modify storage sacrifice:thief item set from entity @s Inventory[{Slot:6b}]
data remove storage sacrifice:thief item.Slot
data modify entity @n[tag=sacrifice_thief_grabbing] equipment.chest.components."minecraft:bundle_contents" append from storage sacrifice:thief item
item replace entity @s hotbar.6 with air
scoreboard players set #done sacrifice.thief 1
