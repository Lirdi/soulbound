scoreboard players set #done sacrifice.thief 0
execute store result score #r sacrifice.thief run random value 0..8
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 0 if items entity @s hotbar.0 * run function sacrifice:thief/slot_0
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 1 if items entity @s hotbar.1 * run function sacrifice:thief/slot_1
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 2 if items entity @s hotbar.2 * run function sacrifice:thief/slot_2
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 3 if items entity @s hotbar.3 * run function sacrifice:thief/slot_3
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 4 if items entity @s hotbar.4 * run function sacrifice:thief/slot_4
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 5 if items entity @s hotbar.5 * run function sacrifice:thief/slot_5
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 6 if items entity @s hotbar.6 * run function sacrifice:thief/slot_6
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 7 if items entity @s hotbar.7 * run function sacrifice:thief/slot_7
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 8 if items entity @s hotbar.8 * run function sacrifice:thief/slot_8
scoreboard players add #r sacrifice.thief 1
execute if score #r sacrifice.thief matches 9.. run scoreboard players set #r sacrifice.thief 0
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 0 if items entity @s hotbar.0 * run function sacrifice:thief/slot_0
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 1 if items entity @s hotbar.1 * run function sacrifice:thief/slot_1
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 2 if items entity @s hotbar.2 * run function sacrifice:thief/slot_2
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 3 if items entity @s hotbar.3 * run function sacrifice:thief/slot_3
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 4 if items entity @s hotbar.4 * run function sacrifice:thief/slot_4
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 5 if items entity @s hotbar.5 * run function sacrifice:thief/slot_5
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 6 if items entity @s hotbar.6 * run function sacrifice:thief/slot_6
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 7 if items entity @s hotbar.7 * run function sacrifice:thief/slot_7
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 8 if items entity @s hotbar.8 * run function sacrifice:thief/slot_8
scoreboard players add #r sacrifice.thief 1
execute if score #r sacrifice.thief matches 9.. run scoreboard players set #r sacrifice.thief 0
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 0 if items entity @s hotbar.0 * run function sacrifice:thief/slot_0
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 1 if items entity @s hotbar.1 * run function sacrifice:thief/slot_1
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 2 if items entity @s hotbar.2 * run function sacrifice:thief/slot_2
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 3 if items entity @s hotbar.3 * run function sacrifice:thief/slot_3
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 4 if items entity @s hotbar.4 * run function sacrifice:thief/slot_4
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 5 if items entity @s hotbar.5 * run function sacrifice:thief/slot_5
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 6 if items entity @s hotbar.6 * run function sacrifice:thief/slot_6
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 7 if items entity @s hotbar.7 * run function sacrifice:thief/slot_7
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 8 if items entity @s hotbar.8 * run function sacrifice:thief/slot_8
scoreboard players add #r sacrifice.thief 1
execute if score #r sacrifice.thief matches 9.. run scoreboard players set #r sacrifice.thief 0
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 0 if items entity @s hotbar.0 * run function sacrifice:thief/slot_0
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 1 if items entity @s hotbar.1 * run function sacrifice:thief/slot_1
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 2 if items entity @s hotbar.2 * run function sacrifice:thief/slot_2
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 3 if items entity @s hotbar.3 * run function sacrifice:thief/slot_3
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 4 if items entity @s hotbar.4 * run function sacrifice:thief/slot_4
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 5 if items entity @s hotbar.5 * run function sacrifice:thief/slot_5
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 6 if items entity @s hotbar.6 * run function sacrifice:thief/slot_6
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 7 if items entity @s hotbar.7 * run function sacrifice:thief/slot_7
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 8 if items entity @s hotbar.8 * run function sacrifice:thief/slot_8
scoreboard players add #r sacrifice.thief 1
execute if score #r sacrifice.thief matches 9.. run scoreboard players set #r sacrifice.thief 0
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 0 if items entity @s hotbar.0 * run function sacrifice:thief/slot_0
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 1 if items entity @s hotbar.1 * run function sacrifice:thief/slot_1
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 2 if items entity @s hotbar.2 * run function sacrifice:thief/slot_2
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 3 if items entity @s hotbar.3 * run function sacrifice:thief/slot_3
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 4 if items entity @s hotbar.4 * run function sacrifice:thief/slot_4
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 5 if items entity @s hotbar.5 * run function sacrifice:thief/slot_5
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 6 if items entity @s hotbar.6 * run function sacrifice:thief/slot_6
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 7 if items entity @s hotbar.7 * run function sacrifice:thief/slot_7
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 8 if items entity @s hotbar.8 * run function sacrifice:thief/slot_8
scoreboard players add #r sacrifice.thief 1
execute if score #r sacrifice.thief matches 9.. run scoreboard players set #r sacrifice.thief 0
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 0 if items entity @s hotbar.0 * run function sacrifice:thief/slot_0
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 1 if items entity @s hotbar.1 * run function sacrifice:thief/slot_1
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 2 if items entity @s hotbar.2 * run function sacrifice:thief/slot_2
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 3 if items entity @s hotbar.3 * run function sacrifice:thief/slot_3
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 4 if items entity @s hotbar.4 * run function sacrifice:thief/slot_4
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 5 if items entity @s hotbar.5 * run function sacrifice:thief/slot_5
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 6 if items entity @s hotbar.6 * run function sacrifice:thief/slot_6
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 7 if items entity @s hotbar.7 * run function sacrifice:thief/slot_7
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 8 if items entity @s hotbar.8 * run function sacrifice:thief/slot_8
scoreboard players add #r sacrifice.thief 1
execute if score #r sacrifice.thief matches 9.. run scoreboard players set #r sacrifice.thief 0
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 0 if items entity @s hotbar.0 * run function sacrifice:thief/slot_0
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 1 if items entity @s hotbar.1 * run function sacrifice:thief/slot_1
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 2 if items entity @s hotbar.2 * run function sacrifice:thief/slot_2
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 3 if items entity @s hotbar.3 * run function sacrifice:thief/slot_3
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 4 if items entity @s hotbar.4 * run function sacrifice:thief/slot_4
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 5 if items entity @s hotbar.5 * run function sacrifice:thief/slot_5
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 6 if items entity @s hotbar.6 * run function sacrifice:thief/slot_6
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 7 if items entity @s hotbar.7 * run function sacrifice:thief/slot_7
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 8 if items entity @s hotbar.8 * run function sacrifice:thief/slot_8
scoreboard players add #r sacrifice.thief 1
execute if score #r sacrifice.thief matches 9.. run scoreboard players set #r sacrifice.thief 0
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 0 if items entity @s hotbar.0 * run function sacrifice:thief/slot_0
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 1 if items entity @s hotbar.1 * run function sacrifice:thief/slot_1
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 2 if items entity @s hotbar.2 * run function sacrifice:thief/slot_2
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 3 if items entity @s hotbar.3 * run function sacrifice:thief/slot_3
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 4 if items entity @s hotbar.4 * run function sacrifice:thief/slot_4
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 5 if items entity @s hotbar.5 * run function sacrifice:thief/slot_5
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 6 if items entity @s hotbar.6 * run function sacrifice:thief/slot_6
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 7 if items entity @s hotbar.7 * run function sacrifice:thief/slot_7
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 8 if items entity @s hotbar.8 * run function sacrifice:thief/slot_8
scoreboard players add #r sacrifice.thief 1
execute if score #r sacrifice.thief matches 9.. run scoreboard players set #r sacrifice.thief 0
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 0 if items entity @s hotbar.0 * run function sacrifice:thief/slot_0
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 1 if items entity @s hotbar.1 * run function sacrifice:thief/slot_1
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 2 if items entity @s hotbar.2 * run function sacrifice:thief/slot_2
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 3 if items entity @s hotbar.3 * run function sacrifice:thief/slot_3
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 4 if items entity @s hotbar.4 * run function sacrifice:thief/slot_4
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 5 if items entity @s hotbar.5 * run function sacrifice:thief/slot_5
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 6 if items entity @s hotbar.6 * run function sacrifice:thief/slot_6
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 7 if items entity @s hotbar.7 * run function sacrifice:thief/slot_7
execute if score #done sacrifice.thief matches 0 if score #r sacrifice.thief matches 8 if items entity @s hotbar.8 * run function sacrifice:thief/slot_8
scoreboard players add #r sacrifice.thief 1
execute if score #r sacrifice.thief matches 9.. run scoreboard players set #r sacrifice.thief 0
