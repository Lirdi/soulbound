# the sacred avenue, facing the great temple
execute in sacrifice:sacrifice run tp @s 0 61 -114 0 0
